#!/usr/bin/env bash
# Builds DayMapa. Needs Flutter 3.x + Android SDK (or use the GitHub workflow).
set -e
rm -rf build_tmp
flutter create --org com.daymapa --project-name uni --platforms android build_tmp
cp -r overlay/. build_tmp/
cd build_tmp
rm -f test/widget_test.dart
# flutter_local_notifications needs core library desugaring
G=android/app/build.gradle.kts
if [ -f "$G" ]; then
  sed -i 's/compileOptions {/compileOptions {\n        isCoreLibraryDesugaringEnabled = true/' "$G"
  printf '\ndependencies {\n    coreLibraryDesugaring("com.android.tools:desugar_jdk_libs:2.1.4")\n}\n' >> "$G"
else
  G=android/app/build.gradle
  sed -i 's/compileOptions {/compileOptions {\n        coreLibraryDesugaringEnabled true/' "$G"
  printf '\ndependencies {\n    coreLibraryDesugaring "com.android.tools:desugar_jdk_libs:2.1.4"\n}\n' >> "$G"
fi
flutter pub get
flutter build apk --release
echo "DONE: $(pwd)/build/app/outputs/flutter-apk/app-release.apk"
