import 'dart:convert';
import 'package:hive_flutter/hive_flutter.dart';
import '../domain/models.dart';

/// Offline-first local storage (Hive). No network, no backend.
class Store {
  late Box _b;
  Future<void> init() async {
    await Hive.initFlutter();
    _b = await Hive.openBox('daymapa');
  }

  List<T> _rd<T>(String k, T Function(Map) f) =>
      (jsonDecode(_b.get(k, defaultValue: '[]') as String) as List).map((e) => f(Map<String, dynamic>.from(e))).toList();

  Db load() => Db(_rd('courses', Course.fromMap), _rd('sessions', Session.fromMap));

  void save(Db d) {
    _b.put('courses', jsonEncode(d.courses.map((e) => e.toMap()).toList()));
    _b.put('sessions', jsonEncode(d.sessions.map((e) => e.toMap()).toList()));
  }
}
