import 'dart:convert';
import 'package:flutter/services.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:home_widget/home_widget.dart';
import 'package:timezone/data/latest_all.dart' as tzdata;
import 'package:timezone/timezone.dart' as tz;
import '../domain/models.dart';

const _ch = MethodChannel('daymapa/native');

/// Pushes the schedule to the native side (widget + ongoing notification)
/// and schedules the 15/5-minute alerts.
class Sync {
  static final _n = FlutterLocalNotificationsPlugin();

  static Future<void> init() async {
    tzdata.initializeTimeZones();
    await _n.initialize(const InitializationSettings(android: AndroidInitializationSettings('@mipmap/ic_launcher')));
    try {
      final a = _n.resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>();
      await a?.requestNotificationsPermission();
      await a?.requestExactAlarmsPermission();
    } catch (_) {}
  }

  static List<Occ> upcoming(Db db, int days) {
    final now = DateTime.now();
    final out = <Occ>[];
    for (var i = 0; i < days; i++) {
      out.addAll(occOn(db, DateTime(now.year, now.month, now.day + i)).where((o) => o.end.isAfter(now)));
    }
    return out;
  }

  static Future<void> push(Db db) async {
    try {
      final occ = upcoming(db, 14);
      final json = jsonEncode(occ
          .map((o) => {'s': o.start.millisecondsSinceEpoch, 'e': o.end.millisecondsSinceEpoch, 'code': db.course(o.s.courseId).code, 'venue': o.s.venue})
          .toList());
      await HomeWidget.saveWidgetData<String>('sessions', json);
      await _n.cancelAll();
      final now = DateTime.now();
      var id = 100;
      for (final o in occ.where((o) => o.start.difference(now).inDays < 7)) {
        for (final k in [15, 5]) {
          final t = o.start.subtract(Duration(minutes: k));
          if (!t.isAfter(now) || id > 500) continue;
          final code = db.course(o.s.courseId).code, v = o.s.venue;
          await _n.zonedSchedule(
            id++,
            'Go to ${v.isEmpty ? 'class' : v} for $code',
            '$code${v.isEmpty ? '' : ' · $v'} · ${fm(o.s.start)} (in $k min)',
            tz.TZDateTime.from(t, tz.UTC),
            const NotificationDetails(android: AndroidNotificationDetails('alerts', 'Class alerts', importance: Importance.high, priority: Priority.high)),
            androidScheduleMode: AndroidScheduleMode.exactAllowWhileIdle,
            uiLocalNotificationDateInterpretation: UILocalNotificationDateInterpretation.absoluteTime,
          );
        }
      }
      await _ch.invokeMethod('refresh');
    } catch (_) {}
  }

  static Future<void> keepAlive() async {
    try {
      await _ch.invokeMethod('battery');
    } catch (_) {}
  }
}
