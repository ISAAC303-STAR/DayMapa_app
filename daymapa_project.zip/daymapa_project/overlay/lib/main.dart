import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'data/store.dart';
import 'data/sync.dart';
import 'presentation/app.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final store = Store();
  await store.init();
  await Sync.init();
  runApp(ProviderScope(overrides: [storeProvider.overrideWithValue(store)], child: const DayMapaApp()));
  Sync.push(store.load()); // refresh alerts, widget and notification on every launch
}
