import 'dart:async';
import 'dart:convert';
import 'package:csv/csv.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../data/store.dart';
import '../data/sync.dart';
import '../domain/models.dart';
import '../domain/parser.dart';

const kColors = [0xFF2F6BFF, 0xFFE2557A, 0xFF1FA37A, 0xFFD98A00, 0xFF8A5CF6, 0xFF0FA3B1, 0xFFE0672B, 0xFF5B7083];
int _n = 0;
String _id() => '${DateTime.now().microsecondsSinceEpoch}${_n++}';

final storeProvider = Provider<Store>((_) => throw UnimplementedError());
final dbProvider = NotifierProvider<DbNotifier, Db>(DbNotifier.new);

class BulkResult {
  final int ok;
  final List<String> bad;
  BulkResult(this.ok, this.bad);
}

class DbNotifier extends Notifier<Db> {
  @override
  Db build() => ref.read(storeProvider).load();

  void _commit(Db d) {
    state = d;
    ref.read(storeProvider).save(d);
    Sync.push(d);
  }

  Course _course(Db d, Parsed p) {
    var c = d.courses.where((x) => x.code == p.code).firstOrNull;
    if (c == null) {
      c = Course(id: _id(), code: p.code, color: kColors[d.courses.length % kColors.length]);
      d.courses.add(c);
    }
    if (p.lecturer.isNotEmpty && c.lecturer.isEmpty) c.lecturer = p.lecturer;
    return c;
  }

  void _add(Db d, Parsed p) {
    final c = _course(d, p);
    void put(int dow, String? date, bool rec) => d.sessions.add(Session(id: _id(), courseId: c.id, dow: dow, start: p.start, end: p.end, venue: p.venue, topic: p.topic, date: date, rec: rec));
    if (p.dows.isNotEmpty) {
      for (final w in p.dows) {
        put(w, p.date, p.date == null);
      }
    } else {
      put(DateTime.parse(p.date!).weekday % 7, p.date, false);
    }
  }

  String? addLine(String line) {
    final r = parseLine(line);
    if (r.p == null) return r.err;
    final d = state.copy();
    _add(d, r.p!);
    _commit(d);
    return null;
  }

  BulkResult bulk(String text) {
    final d = state.copy();
    int? ctx;
    var ok = 0;
    final bad = <String>[];
    for (final raw in text.split(RegExp(r'\r?\n'))) {
      final line = raw.trim();
      if (line.isEmpty) continue;
      final w = line.replaceAll(RegExp(r'[:,]'), ' ').trim();
      final dm = dayRe.firstMatch(w);
      if (RegExp(r'^[A-Za-z]+$').hasMatch(w) && dm != null && dm[0] == w) {
        ctx = dowOf(w);
        continue;
      }
      final r = parseLine(line.replaceAll(',', ' '), ctx: ctx, needDay: true);
      if (r.p == null) {
        bad.add('$line — ${r.err}');
        continue;
      }
      _add(d, r.p!);
      ok++;
    }
    if (ok > 0) _commit(d);
    return BulkResult(ok, bad);
  }

  void deleteSession(String id) {
    final d = state.copy()..sessions.removeWhere((s) => s.id == id);
    _commit(d);
  }

  void saveCourse(Course? c, String code, String name, String lec) {
    final d = state.copy();
    if (c == null) {
      final k = code.trim().toUpperCase();
      if (k.isEmpty || d.courses.any((x) => x.code == k)) return;
      d.courses.add(Course(id: _id(), code: k, name: name.trim(), lecturer: lec.trim(), color: kColors[d.courses.length % kColors.length]));
    } else {
      c.name = name.trim();
      c.lecturer = lec.trim();
    }
    _commit(d);
  }

  void deleteCourse(String id) {
    final d = state.copy()
      ..courses.removeWhere((c) => c.id == id)
      ..sessions.removeWhere((s) => s.courseId == id);
    _commit(d);
  }
}

class DayMapaApp extends StatelessWidget {
  const DayMapaApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'DayMapa',
        debugShowCheckedModeBanner: false,
        theme: ThemeData(colorSchemeSeed: const Color(0xFF2F6BFF), useMaterial3: true),
        darkTheme: ThemeData(colorSchemeSeed: const Color(0xFF2F6BFF), brightness: Brightness.dark, useMaterial3: true),
        home: const HomePage(),
      );
}

class HomePage extends ConsumerStatefulWidget {
  const HomePage({super.key});
  @override
  ConsumerState<HomePage> createState() => _HomeState();
}

class _HomeState extends ConsumerState<HomePage> {
  int tab = 0;
  Timer? _t;
  @override
  void initState() {
    super.initState();
    _t = Timer.periodic(const Duration(seconds: 20), (_) => setState(() {}));
  }

  @override
  void dispose() {
    _t?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final db = ref.watch(dbProvider);
    return Scaffold(
      appBar: AppBar(title: const Text('DayMapa'), actions: [
        IconButton(tooltip: 'Keep alerts running (Huawei)', icon: const Icon(Icons.battery_saver), onPressed: Sync.keepAlive),
      ]),
      body: [_today(db), _week(db), _courses(db)][tab],
      floatingActionButton: tab == 2
          ? FloatingActionButton(onPressed: () => _courseDialog(null), child: const Icon(Icons.add))
          : FloatingActionButton(onPressed: _addSheet, child: const Icon(Icons.add)),
      bottomNavigationBar: NavigationBar(
        selectedIndex: tab,
        onDestinationSelected: (i) => setState(() => tab = i),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.timeline), label: 'Today'),
          NavigationDestination(icon: Icon(Icons.view_week), label: 'Week'),
          NavigationDestination(icon: Icon(Icons.school), label: 'Courses'),
        ],
      ),
    );
  }

  // ---------- Today ----------
  Widget _today(Db db) {
    final now = DateTime.now(), l = occOn(db, now), cl = clashes(l);
    Occ? cur, nx;
    for (final o in l) {
      if (cur == null && !now.isBefore(o.start) && now.isBefore(o.end)) cur = o;
      if (nx == null && o.start.isAfter(now)) nx = o;
    }
    String line(Occ? o, bool isNow) {
      if (o == null) return isNow ? 'Nothing on right now' : 'Nothing more today';
      final c = db.course(o.s.courseId).code, v = o.s.venue.isEmpty ? '' : ' in ${o.s.venue}';
      return isNow ? '$c$v · ${_left(o, now)} min left' : '$c$v at ${fm(o.s.start)}';
    }

    return ListView(padding: const EdgeInsets.all(16), children: [
      Text(dayNames[now.weekday % 7], style: Theme.of(context).textTheme.headlineMedium?.copyWith(fontWeight: FontWeight.w800)),
      const SizedBox(height: 10),
      Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(color: const Color(0xFF14213D), borderRadius: BorderRadius.circular(20)),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('NOW', style: TextStyle(color: Colors.white60, fontSize: 12)),
          Text(line(cur, true), style: const TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.w800)),
          const SizedBox(height: 10),
          const Text('NEXT', style: TextStyle(color: Colors.white60, fontSize: 12)),
          Text(line(nx, false), style: const TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.w700)),
        ]),
      ),
      const SizedBox(height: 20),
      if (l.isEmpty)
        const Padding(padding: EdgeInsets.all(30), child: Center(child: Text('No sessions today.\nTap + to paste your timetable.', textAlign: TextAlign.center)))
      else
        ...l.map((o) => _node(db, o, now, cl)),
    ]);
  }

  int _left(Occ o, DateTime now) => (o.end.difference(now).inSeconds / 60).ceil();

  Widget _node(Db db, Occ o, DateTime now, Map<String, List<Occ>> cl) {
    final past = !now.isBefore(o.end), cur = !past && !now.isBefore(o.start);
    final c = db.course(o.s.courseId);
    final grey = Theme.of(context).colorScheme.outlineVariant;
    return Container(
      margin: const EdgeInsets.only(left: 7, bottom: 14),
      padding: const EdgeInsets.only(left: 22),
      decoration: BoxDecoration(border: Border(left: BorderSide(color: grey, width: 3))),
      child: Stack(clipBehavior: Clip.none, children: [
        _SessionCard(db: db, o: o, now: now, cl: cl[o.s.id], onTap: () => _detail(db, o), showTimer: true),
        Positioned(
          left: -31.5,
          top: 16,
          child: cur
              ? const _Pulse()
              : Container(width: 16, height: 16, decoration: BoxDecoration(shape: BoxShape.circle, color: past ? grey : Theme.of(context).colorScheme.surface, border: Border.all(color: past ? grey : Color(c.color), width: 3))),
        ),
      ]),
    );
  }

  void _detail(Db db, Occ o) {
    final c = db.course(o.s.courseId);
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text('${c.code}${c.name.isEmpty ? '' : ' · ${c.name}'}'),
        content: Text('${fm(o.s.start)} – ${fm(o.s.end)}\n${o.s.venue.isEmpty ? 'No venue' : o.s.venue}${o.s.topic.isEmpty ? '' : '\nTopic: ${o.s.topic}'}${c.lecturer.isEmpty ? '' : '\nLecturer: ${c.lecturer}'}\n${o.s.rec ? 'Repeats every ${dayNames[o.s.dow]}' : 'One-time (${o.s.date})'}'),
        actions: [
          TextButton(
              onPressed: () {
                ref.read(dbProvider.notifier).deleteSession(o.s.id);
                Navigator.pop(ctx);
              },
              child: const Text('Delete')),
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Close')),
        ],
      ),
    );
  }

  // ---------- Week ----------
  Widget _week(Db db) {
    final now = DateTime.now(), mon = DateTime(now.year, now.month, now.day - (now.weekday - 1));
    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      padding: const EdgeInsets.all(16),
      child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
        for (var i = 0; i < 7; i++) _col(db, DateTime(mon.year, mon.month, mon.day + i), now),
      ]),
    );
  }

  Widget _col(Db db, DateTime d, DateTime now) {
    final l = occOn(db, d), cl = clashes(l), today = ymd(d) == ymd(now);
    return SizedBox(
      width: 230,
      child: Padding(
        padding: const EdgeInsets.only(right: 12),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('${dayNames[d.weekday % 7]} ${d.day}', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800, color: today ? Theme.of(context).colorScheme.primary : null)),
          const SizedBox(height: 8),
          if (l.isEmpty) const Text('Free day'),
          ...l.map((o) => Padding(padding: const EdgeInsets.only(bottom: 8), child: _SessionCard(db: db, o: o, now: today ? now : (d.isBefore(now) ? now : DateTime(2000)), cl: cl[o.s.id], onTap: () => _detail(db, o), showTimer: false))),
        ]),
      ),
    );
  }

  // ---------- Courses ----------
  Widget _courses(Db db) {
    if (db.courses.isEmpty) return const Center(child: Text('No courses yet.\nThey appear when you add sessions.', textAlign: TextAlign.center));
    return ListView(padding: const EdgeInsets.all(12), children: [
      for (final c in db.courses)
        Card(
          child: ListTile(
            leading: CircleAvatar(backgroundColor: Color(c.color), radius: 10),
            title: Text(c.code, style: const TextStyle(fontWeight: FontWeight.w800)),
            subtitle: Text([c.name, c.lecturer].where((e) => e.isNotEmpty).join(' · ')),
            onTap: () => _courseDialog(c),
            trailing: IconButton(icon: const Icon(Icons.delete_outline), onPressed: () => ref.read(dbProvider.notifier).deleteCourse(c.id)),
          ),
        ),
    ]);
  }

  void _courseDialog(Course? c) {
    final code = TextEditingController(text: c?.code), name = TextEditingController(text: c?.name), lec = TextEditingController(text: c?.lecturer);
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(c == null ? 'New course' : 'Edit ${c.code}'),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          if (c == null) TextField(controller: code, decoration: const InputDecoration(labelText: 'Code, e.g. CSC201')),
          TextField(controller: name, decoration: const InputDecoration(labelText: 'Name')),
          TextField(controller: lec, decoration: const InputDecoration(labelText: 'Lecturer')),
        ]),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')),
          FilledButton(
              onPressed: () {
                ref.read(dbProvider.notifier).saveCourse(c, code.text, name.text, lec.text);
                Navigator.pop(ctx);
              },
              child: const Text('Save')),
        ],
      ),
    );
  }

  // ---------- Add / import ----------
  void _addSheet() {
    final q = TextEditingController(), b = TextEditingController();
    var err = '';
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, set) => Padding(
          padding: EdgeInsets.fromLTRB(16, 8, 16, MediaQuery.of(ctx).viewInsets.bottom + 16),
          child: DefaultTabController(
            length: 2,
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              const TabBar(tabs: [Tab(text: 'Quick add'), Tab(text: 'Paste timetable')]),
              SizedBox(
                height: 250,
                child: TabBarView(children: [
                  Column(children: [
                    const SizedBox(height: 12),
                    TextField(controller: q, decoration: const InputDecoration(hintText: 'MTH110 LT2 tomorrow 9-10 Integration', border: OutlineInputBorder())),
                    const SizedBox(height: 6),
                    const Text('"Mon" repeats weekly. "today" / "tomorrow" is one-time.', style: TextStyle(fontSize: 12)),
                    const Spacer(),
                    SizedBox(
                      width: double.infinity,
                      child: FilledButton(
                          onPressed: () {
                            final e = ref.read(dbProvider.notifier).addLine(q.text);
                            if (e == null) {
                              Navigator.pop(ctx);
                            } else {
                              set(() => err = e);
                            }
                          },
                          child: const Text('Add')),
                    ),
                  ]),
                  Column(children: [
                    const SizedBox(height: 12),
                    Expanded(child: TextField(controller: b, maxLines: null, expands: true, textAlignVertical: TextAlignVertical.top, decoration: const InputDecoration(hintText: 'Monday\nMTH110 LT2 8-10 Integration\nPHY101 Hall B 11-12', border: OutlineInputBorder()))),
                    const SizedBox(height: 8),
                    Row(children: [
                      OutlinedButton(
                          onPressed: () async {
                            final f = await FilePicker.platform.pickFiles(type: FileType.custom, allowedExtensions: ['csv', 'txt'], withData: true);
                            final file = f?.files.single;
                            if (file?.bytes == null) return;
                            var t = utf8.decode(file!.bytes!, allowMalformed: true).replaceAll('\r\n', '\n');
                            if (file.extension == 'csv') {
                              t = const CsvToListConverter().convert(t, eol: '\n', shouldParseNumbers: false).map((r) => r.join(' ')).join('\n');
                            }
                            b.text = t;
                          },
                          child: const Text('Load CSV')),
                      const SizedBox(width: 8),
                      Expanded(
                        child: FilledButton(
                            onPressed: () {
                              final r = ref.read(dbProvider.notifier).bulk(b.text);
                              if (r.bad.isEmpty && r.ok > 0) {
                                Navigator.pop(ctx);
                              } else {
                                set(() => err = r.bad.isEmpty ? 'Nothing to import.' : 'Imported ${r.ok}. Skipped ${r.bad.length}:\n${r.bad.join('\n')}');
                              }
                            },
                            child: const Text('Import')),
                      ),
                    ]),
                  ]),
                ]),
              ),
              if (err.isNotEmpty) Text(err, style: TextStyle(color: Theme.of(ctx).colorScheme.error, fontSize: 13)),
            ]),
          ),
        ),
      ),
    );
  }
}

class _SessionCard extends StatelessWidget {
  final Db db;
  final Occ o;
  final DateTime now;
  final List<Occ>? cl;
  final VoidCallback onTap;
  final bool showTimer;
  const _SessionCard({required this.db, required this.o, required this.now, required this.cl, required this.onTap, required this.showTimer});

  @override
  Widget build(BuildContext context) {
    final c = db.course(o.s.courseId), s = o.s;
    final past = !now.isBefore(o.end), cur = !past && !now.isBefore(o.start);
    final blue = Theme.of(context).colorScheme.primary;
    final strike = past ? TextDecoration.lineThrough : null;
    final left = (o.end.difference(now).inSeconds / 60).ceil();
    return Opacity(
      opacity: past ? 0.5 : 1,
      child: Card(
        margin: EdgeInsets.zero,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16), side: cur ? BorderSide(color: blue, width: 2) : BorderSide.none),
        child: InkWell(
          borderRadius: BorderRadius.circular(16),
          onTap: onTap,
          child: Container(
            padding: const EdgeInsets.fromLTRB(14, 10, 14, 10),
            decoration: BoxDecoration(border: Border(left: BorderSide(color: past ? Colors.grey : Color(c.color), width: 5)), borderRadius: BorderRadius.circular(16)),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                Text('${fm(s.start)} – ${fm(s.end)}', style: const TextStyle(fontSize: 12)),
                if (cur && showTimer) Text('$left min left', style: TextStyle(color: blue, fontWeight: FontWeight.w800)),
              ]),
              Text('${c.code}${s.venue.isEmpty ? '' : ' · ${s.venue}'}', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800, decoration: strike)),
              if (c.name.isNotEmpty || s.topic.isNotEmpty) Text([c.name, s.topic].where((e) => e.isNotEmpty).join(' — '), style: TextStyle(decoration: strike)),
              if (cur && showTimer) Padding(padding: const EdgeInsets.only(top: 8), child: LinearProgressIndicator(value: (now.difference(o.start).inSeconds / o.end.difference(o.start).inSeconds).clamp(0.0, 1.0))),
              if (cl != null) Padding(padding: const EdgeInsets.only(top: 6), child: Chip(visualDensity: VisualDensity.compact, backgroundColor: Colors.amber, label: Text('Clashes with ${cl!.map((x) => db.course(x.s.courseId).code).join(', ')}', style: const TextStyle(fontSize: 12, color: Colors.black)))),
            ]),
          ),
        ),
      ),
    );
  }
}

class _Pulse extends StatefulWidget {
  const _Pulse();
  @override
  State<_Pulse> createState() => _PulseState();
}

class _PulseState extends State<_Pulse> with SingleTickerProviderStateMixin {
  late final AnimationController a = AnimationController(vsync: this, duration: const Duration(milliseconds: 1400))..repeat();
  @override
  void dispose() {
    a.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => AnimatedBuilder(
        animation: a,
        builder: (_, __) => Container(
          width: 16,
          height: 16,
          decoration: BoxDecoration(shape: BoxShape.circle, color: const Color(0xFF2F6BFF), boxShadow: [BoxShadow(color: const Color(0xFF2F6BFF).withOpacity(0.5 * (1 - a.value)), spreadRadius: 12 * a.value)]),
        ),
      );
}
