class Course {
  String id, code, name, lecturer;
  int color;
  Course({required this.id, required this.code, this.name = '', this.lecturer = '', required this.color});
  Map<String, dynamic> toMap() => {'id': id, 'code': code, 'name': name, 'lecturer': lecturer, 'color': color};
  factory Course.fromMap(Map m) => Course(id: m['id'], code: m['code'], name: m['name'] ?? '', lecturer: m['lecturer'] ?? '', color: m['color']);
}

class Session {
  final String id, courseId, venue, topic;
  final int dow, start, end; // dow 0=Sunday, minutes from midnight
  final String? date; // set for one-time sessions
  final bool rec;
  const Session({required this.id, required this.courseId, required this.dow, required this.start, required this.end, this.venue = '', this.topic = '', this.date, this.rec = true});
  Map<String, dynamic> toMap() => {'id': id, 'courseId': courseId, 'dow': dow, 'start': start, 'end': end, 'venue': venue, 'topic': topic, 'date': date, 'rec': rec};
  factory Session.fromMap(Map m) => Session(id: m['id'], courseId: m['courseId'], dow: m['dow'], start: m['start'], end: m['end'], venue: m['venue'] ?? '', topic: m['topic'] ?? '', date: m['date'], rec: m['rec'] ?? true);
}

class Db {
  final List<Course> courses;
  final List<Session> sessions;
  Db(this.courses, this.sessions);
  Db copy() => Db([...courses], [...sessions]);
  Course course(String id) => courses.firstWhere((c) => c.id == id, orElse: () => Course(id: '', code: '?', color: 0xFF2F6BFF));
}

class Occ {
  final Session s;
  final DateTime start, end;
  Occ(this.s, this.start, this.end);
}

const dayNames = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
String ymd(DateTime d) => '${d.year}-${d.month.toString().padLeft(2, '0')}-${d.day.toString().padLeft(2, '0')}';
String fm(int m) {
  var h = m ~/ 60;
  final mm = m % 60, ap = h >= 12 ? 'pm' : 'am';
  h = h % 12 == 0 ? 12 : h % 12;
  return '$h${mm == 0 ? '' : ':${mm.toString().padLeft(2, '0')}'}$ap';
}

List<Occ> occOn(Db db, DateTime day) {
  final k = ymd(day);
  final l = db.sessions
      .where((s) => s.rec ? s.dow == day.weekday % 7 : s.date == k)
      .map((s) => Occ(s, DateTime(day.year, day.month, day.day, 0, s.start), DateTime(day.year, day.month, day.day, 0, s.end)))
      .toList();
  l.sort((a, b) => a.start.compareTo(b.start));
  return l;
}

/// Session id -> sessions it overlaps with.
Map<String, List<Occ>> clashes(List<Occ> l) {
  final m = <String, List<Occ>>{};
  for (var i = 0; i < l.length; i++) {
    for (var j = i + 1; j < l.length; j++) {
      if (l[i].start.isBefore(l[j].end) && l[j].start.isBefore(l[i].end)) {
        (m[l[i].s.id] ??= []).add(l[j]);
        (m[l[j].s.id] ??= []).add(l[i]);
      }
    }
  }
  return m;
}
