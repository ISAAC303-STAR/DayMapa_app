import 'models.dart';

final dayRe = RegExp(r'\b(sun(?:day)?|mon(?:day)?|tue(?:s(?:day)?)?|wed(?:nesday)?|thu(?:r(?:s(?:day)?)?)?|fri(?:day)?|sat(?:urday)?)\b', caseSensitive: false);
int dowOf(String w) => ['sun', 'mon', 'tue', 'wed', 'thu', 'fri', 'sat'].indexOf(w.substring(0, 3).toLowerCase());

class Parsed {
  String code, venue, topic, lecturer;
  List<int> dows;
  String? date;
  int start, end;
  Parsed(this.code, this.venue, this.topic, this.lecturer, this.dows, this.date, this.start, this.end);
}

class Result {
  final Parsed? p;
  final String? err;
  Result(this.p, this.err);
}

/// "MTH110 LT2 tomorrow 9-10 Integration Dr. Bello"
Result parseLine(String line, {int? ctx, bool needDay = false}) {
  var s = ' ${line.trim()} ';
  final dows = <int>[];
  String? date, code;
  var lect = '';
  s = s.replaceAll(RegExp(r'\bevery\b', caseSensitive: false), ' ');
  for (final m in RegExp(r'\b([A-Za-z]{2,4})\s?(\d{3})\b').allMatches(s)) {
    if (!RegExp(r'^(room|hall|lab|lt|block|rm)$', caseSensitive: false).hasMatch(m[1]!)) {
      code = (m[1]! + m[2]!).toUpperCase();
      s = s.replaceFirst(m[0]!, ' ');
      break;
    }
  }
  if (code == null) return Result(null, 'No course code found (like MTH110)');
  final lm = RegExp(r'\b(?:Dr|Prof|Mr|Mrs|Engr)\.?\s+[A-Z][a-z]+').firstMatch(s);
  if (lm != null) {
    lect = lm[0]!.trim();
    s = s.replaceFirst(lm[0]!, ' ');
  }
  s = s.replaceAllMapped(dayRe, (m) {
    dows.add(dowOf(m[0]!));
    return ' ';
  });
  final now = DateTime.now();
  final tmr = RegExp(r'\btomorrow\b', caseSensitive: false), tdy = RegExp(r'\btoday\b', caseSensitive: false);
  if (tmr.hasMatch(s)) {
    date = ymd(now.add(const Duration(days: 1)));
    s = s.replaceAll(tmr, ' ');
  } else if (tdy.hasMatch(s)) {
    date = ymd(now);
    s = s.replaceAll(tdy, ' ');
  }
  final tm = RegExp(r'(\d{1,2})(?::(\d{2}))?\s*(am|pm)?\s*(?:-|–|—|to)\s*(\d{1,2})(?::(\d{2}))?\s*(am|pm)?', caseSensitive: false).firstMatch(s);
  if (tm == null) return Result(null, 'No time range found (try 9-10 or 9:30-11am)');
  s = s.replaceFirst(tm[0]!, ' ');
  var a = int.parse(tm[1]!), b = int.parse(tm[4]!);
  final ap1 = (tm[3] ?? '').toLowerCase(), ap2 = (tm[6] ?? '').toLowerCase();
  int cv(int h, String ap) => ap == 'pm' && h < 12 ? h + 12 : (ap == 'am' && h == 12 ? 0 : h);
  if (ap1 != '' || ap2 != '') {
    a = cv(a, ap1 != '' ? ap1 : (ap2 == 'pm' && a != 12 && a > b % 12 ? 'am' : ap2));
    b = cv(b, ap2 != '' ? ap2 : ap1);
  } else {
    if (a < 7) a += 12;
    if (b < 7) b += 12;
    if (b <= a && b < 12) b += 12;
  }
  final st = a * 60 + (int.tryParse(tm[2] ?? '') ?? 0), en = b * 60 + (int.tryParse(tm[5] ?? '') ?? 0);
  if (en <= st) return Result(null, 'End time is before start time');
  final tk = s.trim().split(RegExp(r'\s+')).where((e) => e.isNotEmpty).toList();
  var venue = '';
  final i = tk.indexWhere((t) => RegExp(r'^(LT|LH|LR|Theatre|Hall|Room|Rm|Lab|Block)\w*$', caseSensitive: false).hasMatch(t) || RegExp(r'^[A-Za-z]{1,4}\d{1,3}[A-Za-z]?$').hasMatch(t));
  if (i >= 0) {
    venue = tk[i];
    if (RegExp(r'^(Hall|Room|Rm|Lab|Block|Theatre)$', caseSensitive: false).hasMatch(venue) && i + 1 < tk.length) {
      venue += ' ${tk[i + 1]}';
      tk.removeRange(i, i + 2);
    } else {
      tk.removeAt(i);
    }
  }
  if (dows.isEmpty && date == null) {
    if (ctx != null) {
      dows.add(ctx);
    } else if (needDay) {
      return Result(null, 'No day (put a day name line above it)');
    } else {
      date = ymd(now);
    }
  }
  return Result(Parsed(code, venue, tk.join(' '), lect, dows, date, st, en), null);
}
