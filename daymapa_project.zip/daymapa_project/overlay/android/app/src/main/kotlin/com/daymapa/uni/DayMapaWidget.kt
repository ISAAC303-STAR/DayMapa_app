package com.daymapa.uni

import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context

class DayMapaWidget : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) { Ticker.refresh(context) }
    override fun onEnabled(context: Context) { Ticker.refresh(context) }
}
