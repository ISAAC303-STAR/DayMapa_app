package com.daymapa.uni

import android.content.ComponentName
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel

class MainActivity : FlutterActivity() {
    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, "daymapa/native").setMethodCallHandler { call, result ->
            when (call.method) {
                "refresh" -> { Ticker.refresh(applicationContext); result.success(null) }
                "battery" -> { openBatterySettings(); result.success(null) }
                else -> result.notImplemented()
            }
        }
    }

    // Huawei EMUI kills background apps; send the user to the "App launch" / protected-apps screen.
    private fun openBatterySettings() {
        val targets = listOf(
            ComponentName("com.huawei.systemmanager", "com.huawei.systemmanager.startupmgr.ui.StartupNormalAppListActivity"),
            ComponentName("com.huawei.systemmanager", "com.huawei.systemmanager.optimize.process.ProtectActivity")
        )
        for (c in targets) {
            try { startActivity(Intent().setComponent(c)); return } catch (e: Exception) { }
        }
        try { startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) }
        catch (e: Exception) { startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))) }
    }
}
