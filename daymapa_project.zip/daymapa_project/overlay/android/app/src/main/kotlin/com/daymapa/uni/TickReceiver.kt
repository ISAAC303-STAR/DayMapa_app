package com.daymapa.uni

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class TickReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) { Ticker.refresh(context) }
}
