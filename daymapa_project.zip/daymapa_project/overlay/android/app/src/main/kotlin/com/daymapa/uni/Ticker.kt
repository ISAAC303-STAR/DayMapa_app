package com.daymapa.uni

import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Build
import android.widget.RemoteViews
import androidx.core.app.NotificationCompat
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Computes NOW/NEXT from the schedule Flutter saved, updates the widget and the
 *  ongoing notification, then sets an exact alarm for the next change. No Flutter engine needed. */
object Ticker {
    const val ACTION = "com.daymapa.uni.TICK"
    private const val CH = "ongoing"

    private fun venue(o: JSONObject) = o.optString("venue").let { if (it.isEmpty()) "" else " in $it" }

    private fun label(ms: Long, now: Long): String {
        val d = SimpleDateFormat("yyyyMMdd", Locale.US)
        val same = d.format(Date(ms)) == d.format(Date(now))
        return SimpleDateFormat(if (same) "h:mm a" else "EEE h:mm a", Locale.getDefault()).format(Date(ms))
    }

    fun refresh(ctx: Context) {
        val now = System.currentTimeMillis()
        val arr = try {
            JSONArray(ctx.getSharedPreferences("HomeWidgetPreferences", Context.MODE_PRIVATE).getString("sessions", "[]"))
        } catch (e: Exception) { JSONArray() }
        var cur: JSONObject? = null
        var nxt: JSONObject? = null
        var nextTick = Long.MAX_VALUE
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val s = o.getLong("s"); val e = o.getLong("e")
            if (now in s until e && cur == null) cur = o
            if (s > now) { if (nxt == null) nxt = o; nextTick = minOf(nextTick, s) }
            if (e > now) nextTick = minOf(nextTick, e)
        }
        val nowLine = if (cur != null) {
            val left = Math.ceil((cur.getLong("e") - now) / 60000.0).toInt()
            "NOW: ${cur.getString("code")}${venue(cur)} · $left min left"
        } else "NOW: nothing on"
        val nextLine = if (nxt != null) "NEXT: ${nxt.getString("code")}${venue(nxt)} at ${label(nxt.getLong("s"), now)}" else "NEXT: nothing scheduled"

        val launch = ctx.packageManager.getLaunchIntentForPackage(ctx.packageName)
        val open = PendingIntent.getActivity(ctx, 0, launch, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)

        // Widget
        val mgr = AppWidgetManager.getInstance(ctx)
        for (id in mgr.getAppWidgetIds(ComponentName(ctx, DayMapaWidget::class.java))) {
            val rv = RemoteViews(ctx.packageName, R.layout.widget)
            rv.setTextViewText(R.id.now, nowLine)
            rv.setTextViewText(R.id.next, nextLine)
            rv.setOnClickPendingIntent(R.id.root, open)
            mgr.updateAppWidget(id, rv)
        }

        // Ongoing notification
        try {
            val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            if (Build.VERSION.SDK_INT >= 26) nm.createNotificationChannel(NotificationChannel(CH, "Now and next", NotificationManager.IMPORTANCE_LOW))
            val n = NotificationCompat.Builder(ctx, CH)
                .setSmallIcon(android.R.drawable.ic_menu_today)
                .setContentTitle(nowLine).setContentText(nextLine)
                .setOngoing(true).setOnlyAlertOnce(true).setShowWhen(false)
                .setContentIntent(open).build()
            nm.notify(1, n)
        } catch (e: Exception) { }

        // Next wake-up: next session boundary, or each minute while a class is on (for the countdown)
        if (cur != null) nextTick = minOf(nextTick, (now / 60000 + 1) * 60000)
        if (nextTick == Long.MAX_VALUE) nextTick = now + 6 * 3600 * 1000
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val pi = PendingIntent.getBroadcast(ctx, 7, Intent(ctx, TickReceiver::class.java).setAction(ACTION), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        try {
            if (Build.VERSION.SDK_INT >= 31 && !am.canScheduleExactAlarms()) am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, nextTick, pi)
            else am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, nextTick, pi)
        } catch (e: SecurityException) { am.set(AlarmManager.RTC_WAKEUP, nextTick, pi) }
    }
}
