# DayMapa (com.daymapa.uni)
Build: `bash setup.sh` (Flutter 3.x + Android SDK), or push this folder to GitHub and run the "Build APK" action.
Output: build_tmp/build/app/outputs/flutter-apk/app-release.apk (debug-signed; fine for sideloading).
Huawei: Settings > Battery > App launch > DayMapa > Manage manually (enable all three toggles). The battery icon in the app opens this screen.
